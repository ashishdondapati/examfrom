import sqlite3

connection = sqlite3.connect(r"C:\Users\DondapaA\Downloads\Exam-Portal-main\Exam-Portal-main\Exam\db.sqlite3")
cursor = connection.cursor()
cursor.execute("CREATE TABLE quest(id Text,id2 TEXT ,question TEXT,answer TEXT,marks INTEGER)")
import pandas as pd 
df=pd.read_excel('a.xlsx')
lis=[]
for i in range(len(df)):
   lis.append(tuple(df.iloc[i]))
   
print(lis)   
cursor.executemany("INSERT INTO quest VALUES(?,?,?,?,?)",lis)
connection.close()



