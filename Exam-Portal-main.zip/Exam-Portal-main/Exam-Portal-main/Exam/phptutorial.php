<?php
if (isset($_POST['submit'])){
   $file =$_FILES['file'];

   $fileName =$_FILES['file']['name'];
   $fileTmpName =$_FILES['file']['tmp_name'];
   $fileSize =$_FILES['file']['size'];
   $fileerror =$_FILES['file']['error'];
   $fileType =$_FILES['file']['type'];

 $fileExt=explode('.',$filename);
 $fileActualExt=strtolower(end($fileExt));
 
 $allowed=array('xlsx','xls');
 
 if (in_array($fileActualExt,$allowed)){  
  if($fileError ===0){
    if ($fileSize<50000000){
}else{
     echo "your file is too big!";
} else{
     echo "There was an error uploading the file !";                            
}else{
     echo " you cannot upload the file";
}
}

