from django.contrib import admin
from .models import FacultyInfo

# Register your models here.

admin.site.register(FacultyInfo)